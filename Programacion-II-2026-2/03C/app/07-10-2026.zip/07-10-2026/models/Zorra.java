package models;
public class Zorra extends Animal{
    private double peso;

    public Zorra(String nombre, String color, double peso){
        super(nombre, color);
        this.peso = peso;
    }

     public void hacerSonido(){
        System.out.println("Que rico...");
    }
}