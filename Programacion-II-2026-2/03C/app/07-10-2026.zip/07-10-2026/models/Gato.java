package models;
public class Gato extends Animal{
    private boolean male = true;

    public boolean isMale(){
        return male;
    }
    
    public Gato(String nombre, String color, boolean male){
        super(nombre, color);
        this.male = male;
    }

    public Gato(String nombre, boolean male){
        super(nombre);
        this.male = male;
    }

    public Gato(String nombre, String color){
        super(nombre, color);
    }

    public Gato(String nombre){
        super(nombre);
    }

     public void hacerSonido(){
        System.out.println(".....");
    }

}