package models;
public class Animal {
    private String nombre;
    private String color;

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public String getNombre(){
        return nombre;
    }

     public void setColor(String color){
        this.color = color;
    }

    public String getColor(){
        return color;
    }

    public Animal(String nombre, String color){
        this.nombre = nombre;
        this.color = color;
    }

    public Animal(String nombre){
        this.nombre = nombre;
        this.color = "blanco";
    }

    public void hacerSonido(){
        System.out.println("Soy un Animal...");
    }


}