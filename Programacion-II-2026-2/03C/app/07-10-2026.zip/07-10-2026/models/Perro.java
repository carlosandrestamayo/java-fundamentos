package models;
public class Perro extends Animal{

    private int edad;

    public void setEdad(int edad){
        this.edad = edad;
    }

    public int getEdad(){
        return edad;
    }

    public Perro(String nombre, String color, int edad){
        super(nombre, color);
        this.edad = edad;
    }

    @Override
    public void hacerSonido(){
        System.out.println("Soy una Perra o no se...");
    }

    
}