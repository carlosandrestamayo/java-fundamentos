import models.*;
public class Main{
    public static void main(String [] args){

        Perro perro = new Perro("","",2);
        perro.hacerSonido();

        //Animal a = new Animal("fiufiu", "cafe");
        // Perro p = new Perro("Pastor Aleman", "rosadito", 13);
        // Gato g = new Gato("Milluti");
        // Zorra z = new Zorra("Esperanza", "Gomez", 60.0);

        // Animal [] arr = {p, g, z};

        // for(Animal b : arr){
        //     b.hacerSonido();
        // }

        // System.out.printf(
        //     """
        //     Gato:
        //         Nombre: %s
        //         Color: %s
        //         Macho: %b
        //     """, g.getNombre(), g.getColor(), g.isMale()
        // );
    }
}